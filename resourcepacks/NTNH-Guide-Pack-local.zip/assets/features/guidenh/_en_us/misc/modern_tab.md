---
navigation:
  title: Modern Tab List
  parent: misc.md
  icon: minecraft:paper
categories:
    - Miscellaneous Changes
author: Skorched
date: 2026-05-20
---

# Modern Tab List
The modern style of "tab list" has been backported to make server play feel more slick! By customizing `serverutilities.cfg` on a server, you can now configure:
- Player Heads
- Ping Numbers
- Dynamic Columns
- Headers and Footers
<FloatingImage src="../assets/misc/tab_list.png" displayWidth="256" align="left" wrap="square">
  <ImageAnnotation>
    An example of a configured tab list
  </ImageAnnotation>
</FloatingImage>
